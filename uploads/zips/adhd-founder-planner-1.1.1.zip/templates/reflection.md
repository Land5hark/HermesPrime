# Evening Reflection 🌙

## Date: {DATE}

---

### ✅ Today's Wins
_No win is too small!_

1. 
2. 
3. 
4. 
5. 

---

### 📊 What Worked?
_Techniques, conditions, or factors that helped:_

- 

---

### 📊 What Didn't?
_Distractions, blockers, or things that hindered:_

- 

---

### 🔄 Migration Decisions
_Tasks that didn't get completed:_

| Task | Decision | Notes |
|------|----------|-------|
|      | > Tomorrow |       |
|      | < Future |       |
|      | × Done now |       |
|      | ~ Dropped |       |

---

### 🧠 Pattern Notes

**Energy Pattern Today:**
- Started at: /10
- Peak at: /10
- Ended at: /10

**Best Swim Lane:**

**Completed vs Migrated Ratio:**

---

### 🌟 One Thing for Tomorrow
_What will you do differently?_

- 

---

### 🎉 Celebration
_How will you celebrate today's wins?_

- 

---

**Completed:** {TIMESTAMP}
