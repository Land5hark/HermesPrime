# {DAY_NAME}, {DATE} 📝

## 🎯 TODAY'S ONE THING
_What ONE thing must happen for today to be a success?_

**ONE THING:** 

**Status:** ⬜ Not started | 🟡 In progress | ✅ Complete

---

## 🏊 SWIM LANES
_These are context/energy based, NOT time-based_
_Work in whatever lane matches your CURRENT energy_

### 🎯 MUST HAPPEN (The ONE thing)
- [ ] ★ 

### 🔥 HIGH ENERGY (Deep work, creative)
- [ ] 
- [ ] 

### 💧 MEDIUM ENERGY (Standard tasks)
- [ ] 
- [ ] 

### ❄️ LOW ENERGY (Admin, easy wins)
- [ ] 
- [ ] 

### 🚫 NOT TODAY (Captured but deferred)
- [ ] 

---

## 📝 RAPID LOG
_Capture everything as it comes:_

- 

---

## 🎁 DOPAMINE MENU (Today's Rewards)

When I complete the ONE thing:
- [ ] 

When I finish a swim lane:
- [ ] 

---

## 🌙 EVENING REFLECTION
_Fill in at end of day:_

### ✅ Today's Wins
- 

### 📊 What Worked?
- 

### 📊 What Didn't?
- 

### 🔄 Migrated Tasks
- 

### 🌟 One Thing for Tomorrow
- 

---

**Planned:** {TIMESTAMP}  
**Energy Start:** /10  
**Suggested Lane:** 
