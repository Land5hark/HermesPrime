# {MONTH} {YEAR} 📅

## 🎯 Monthly Theme/Intent
_What is this month about?_

**THEME:** 

---

## 📊 Weekly Tracker

| Week | ONE Thing Focus | Tasks Completed | Avg Energy | Key Win |
|------|-----------------|-----------------|------------|---------|
| W1   |                 |                 |            |         |
| W2   |                 |                 |            |         |
| W3   |                 |                 |            |         |
| W4   |                 |                 |            |         |
| W5   |                 |                 |            |         |

---

## 🔄 Recurring Tasks
_Tasks that repeat this month:_

- [ ] 
- [ ] 
- [ ] 

---

## 🏆 Monthly Goals

- [ ] 
- [ ] 
- [ ] 

---

## 📈 Patterns to Watch

- Best energy days:
- Most productive time:
- Common distractions:
- Tasks that keep migrating:

---

## 💡 Ideas & Capture
_Don't forget these:_

- 

---

## 🌟 Month in Review

**Biggest Win:**

**Biggest Lesson:**

**One Thing for Next Month:**

---

Created: {TIMESTAMP}
